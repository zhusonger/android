#!/bin/bash
if [ $# != 1 ]; then
echo "you need give a file name"
exit 1;
fi
echo "Funcions : "
echo "1.Inspect 2.methodcount 3.open"
path=`pwd`/$1
classyPath=$CS/ClassyShark.jar 
read choice
if [ $choice == 1 ];then
java -jar $classyPath -Inspect $path
elif [ $choice == 2 ];then
java -jar $classyPath -methodcounts $path
elif [ $choice == 3 ];then
java -jar $classyPath -open $path
fi

