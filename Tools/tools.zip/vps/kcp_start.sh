echo "start kcptun proxy"
nohup client_darwin_amd64 -c $VPS/client.json& << EOF
exit
