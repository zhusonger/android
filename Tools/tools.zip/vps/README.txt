参考地址: 
安装ss：http://blog.csdn.net/win_turn/article/details/51559867
安装kcptun:https://github.com/clangcn/kcp-server
kcptun优化: http://blog.csdn.net/londa/article/details/70905543?locationNum=10&fps=1
优化:https://blog.phpgao.com/kcptun.html
https://home4love.com/3154.html
https://github.com/xtaci/kcptun/releases