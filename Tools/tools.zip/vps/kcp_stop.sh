echo "killall for kcptun proxy"
killall -9 client_darwin_amd64
